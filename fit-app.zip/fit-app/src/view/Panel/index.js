export { default as Panel } from './PanelComponent'
