import React, { PureComponent } from 'react';
import { Link, Route } from 'react-router-dom';
import { Dashboard, PanelPage1 } from './views';

class PanelComponent extends PureComponent {
  render() {
    return (
      <div>
        <header>
          <p>Panel Header</p>
          <ul>
            <li key="1">
              <Link to="/panel/dashboard">Dashboard</Link>
            </li>
            <li key="2">
              <Link to="/panel/panel-page-1">Panel Page 1</Link>
            </li>
          </ul>
        </header>
        <aside>Panel Sidebar</aside>
        <div>
          <Route path="/panel/dashboard" component={Dashboard} />
          <Route path="/panel/panel-page-1" component={PanelPage1} />
        </div>
        <footer>Panel Footer</footer>
      </div>
    );
  }
}

export default PanelComponent;
