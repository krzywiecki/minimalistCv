import React, { PureComponent } from 'react';

class PanelPage2Component extends PureComponent {
  render() {
    return (
      <div>This is PanelPage2</div>
    );
  }
}

export default PanelPage2Component;
