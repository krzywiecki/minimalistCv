export { default as PanelPage2 } from './PanelPage2Component';
