import React, { PureComponent } from 'react';

class PanelPage1Component extends PureComponent {
  render() {
    return (
      <div>This is PanelPage1</div>
    );
  }
}

export default PanelPage1Component;
