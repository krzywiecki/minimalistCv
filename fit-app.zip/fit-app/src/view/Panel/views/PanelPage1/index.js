export { default as PanelPage1 } from './PanelPage1Component';
