import React, { PureComponent } from 'react';

class DashboardComponent extends PureComponent {
  render() {
    return (
      <div>This is Dashboard</div>
    );
  }
}

export default DashboardComponent;
