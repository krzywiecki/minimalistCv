export { default as Dashboard } from './DashboardComponent';
