import React, { PureComponent } from 'react';

class WebsiteComponent extends PureComponent {
  render() {
    return (
      <div>
        This is our Website
      </div>
    );
  }
}

export default WebsiteComponent;
